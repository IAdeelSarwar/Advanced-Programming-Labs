import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class StrassenTest {

	

	@Test
	public final void testMultiply() {
		 System.out.println("MulMatrixTest - Strassen Algo");
	        int[][] array1 = {{2,5},{5,6}};
	        int[][] array2 = {{5,8,7},{4,8,6}};
	        matMul obj = new matMul();
	        int[][] eResult = {{30,56,44},{49,88,71}};
	        int[][] result = obj.multiplyMatrix(array1, array2);
	        assertArrayEquals(eResult, result);
	     
	}

	@Test
	public final void testSub() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testAdd() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testSplit() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testJoin() {
		fail("Not yet implemented"); // TODO
	}

}
