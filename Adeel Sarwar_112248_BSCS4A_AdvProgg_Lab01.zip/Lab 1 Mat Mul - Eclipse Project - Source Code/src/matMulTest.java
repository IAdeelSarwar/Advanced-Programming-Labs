import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class matMulTest {

	

	@Test
	public final void testMultiply() {
		 
		        System.out.println("MulMatrixTest");
		        int[][] arr1 = {{2,5},{5,6}};
		        int[][] arr2 = {{5,8,7},{4,8,6}};
		        matMul obj = new matMul();
		        int[][] eResult = {{30,56,44},{49,88,71}};
		        int[][] result = obj.multiplyMatrix(arr1, arr2);
		        assertArrayEquals(eResult, result);
		     
		        
		        // TODO review the generated test code and remove the default call to fail.
		       
		    

	}

}
